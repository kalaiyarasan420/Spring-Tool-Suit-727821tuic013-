package com.grocery.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grocery.model.Grocery;
import com.grocery.repository.GroceryRepository;

@Service
public class GroceryService {
	@Autowired
	GroceryRepository groceryRepository;
	
	public List<Grocery> getGroceryDetails(){
		return groceryRepository.findAll();
		
	}
	public Grocery postGroceryDetails(Grocery G) {
		return groceryRepository.save(G);
	}
	public Grocery updateGroceryDetails(Grocery G) {
		return groceryRepository.save(G);
	}
	public String deleteGroceryDetails(int id) {
		groceryRepository.deleteById(id);
		return "Id : "+id+" is deteled";
	}
}